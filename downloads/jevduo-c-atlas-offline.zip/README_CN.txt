JevDuo — Original C / Atlas Continuum

解压后双击 index.html，无需服务器、网络或模型 API。
保留最初 C 版设计、模型与录像，仅移除公开展示不需要的内部路径和来源元数据。
3D 是装配重建，桌面是历史 NorthCUA 录像，运动是既有理想约束仿真记录回放。
不代表新的 JEV 执行、实时物理求解或实物验证。
